# Michaelson Interferometer



This lab is part of a kit that must be picked up at Broida. The kit comes with instructions for the lab, which can be found [here](https://i-fiberoptics.com/pdf/12_0101-45-94x_series.pdf)

<iframe src="https://i-fiberoptics.com/pdf/12_0101-45-94x_series.pdf" height= "700px" width="100%">
