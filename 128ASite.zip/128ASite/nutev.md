# NuTeV Weak Mixing Angle Lab

<center><b>TA: Keegan Downham (kdownham@ucsb.edu)</b></center>

This manual was not written by our department and can be found externally through [this link](https://www-e815.fnal.gov/wma-lab-web/procedure.html)

<iframe width="100%" height="900px" src="https://www-e815.fnal.gov/wma-lab-web/procedure.html"></iframe>