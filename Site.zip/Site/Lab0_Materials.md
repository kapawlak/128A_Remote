# Lab 0: Learning to use iOLab
---
### All Materials Needed:
-  iOLab
- Neodymium magnet
- Ruler
- Steel Screw
- Tape

---

####
test
inline $\int x, y , B_z$

$$\int x, y , B_z$$
